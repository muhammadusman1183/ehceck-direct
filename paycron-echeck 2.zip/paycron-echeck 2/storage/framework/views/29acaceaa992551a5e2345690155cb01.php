<?php $__env->startSection('content'); ?>
<style>
    .auth-wrap{
        max-width: 1100px;
        margin: 36px auto;
        padding: 0 14px;
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji","Segoe UI Emoji";
        color:#0f172a;
    }
    .auth-shell{
        display:grid;
        grid-template-columns: 1.05fr .95fr;
        gap: 16px;
        align-items: stretch;
    }
    @media (max-width: 980px){
        .auth-shell{ grid-template-columns: 1fr; }
    }
    .card{
        background:#fff;
        border:1px solid #e5e7eb;
        border-radius: 18px;
        box-shadow: 0 14px 30px rgba(15,23,42,.08);
        overflow:hidden;
    }
    .hero{
        padding: 22px;
        background: radial-gradient(1200px 600px at 30% 10%, rgba(15,23,42,.10), transparent 55%),
                    linear-gradient(180deg, #0f172a 0%, #111827 60%, #0b1220 100%);
        color:#fff;
        position:relative;
    }
    .hero-inner{
        padding: 18px;
        border: 1px solid rgba(255,255,255,.14);
        border-radius: 18px;
        background: rgba(255,255,255,.06);
        backdrop-filter: blur(10px);
    }
    .brand{
        display:flex;
        align-items:center;
        gap:10px;
        font-weight: 900;
        letter-spacing: -.02em;
    }
    .brand-dot{
        width:10px;height:10px;border-radius:999px;background:#fff;
        box-shadow:0 0 0 4px rgba(255,255,255,.18);
    }
    .hero h1{
        margin: 14px 0 6px;
        font-size: 24px;
        font-weight: 950;
        letter-spacing: -.03em;
        line-height:1.15;
    }
    .hero p{
        margin: 0;
        color: rgba(255,255,255,.80);
        font-size: 13px;
        line-height: 1.5;
    }
    .hero-bullets{
        margin-top: 14px;
        display:grid;
        gap: 10px;
    }
    .bullet{
        display:flex;
        gap: 10px;
        align-items:flex-start;
        padding: 10px 12px;
        border-radius: 14px;
        border: 1px solid rgba(255,255,255,.14);
        background: rgba(255,255,255,.06);
    }
    .bullet .ic{
        width: 28px; height: 28px; border-radius: 10px;
        display:flex; align-items:center; justify-content:center;
        background: rgba(255,255,255,.14);
        font-weight: 900;
    }
    .bullet .txt{
        font-size: 12px;
        color: rgba(255,255,255,.82);
        line-height: 1.45;
    }

    .form{
        padding: 18px;
    }
    .form-head{
        padding: 18px 18px 14px;
        border-bottom: 1px solid #e5e7eb;
        background: linear-gradient(180deg,#ffffff 0%, #f8fafc 150%);
    }
    .form-title{
        margin: 0;
        font-size: 18px;
        font-weight: 950;
        letter-spacing: -.02em;
    }
    .form-sub{
        margin: 6px 0 0;
        color:#64748b;
        font-size: 13px;
        line-height: 1.45;
    }

    .field{ margin-top: 12px; }
    .label{
        display:block;
        font-size: 12px;
        font-weight: 900;
        color:#0f172a;
        margin-bottom: 6px;
    }
    .input{
        width:100%;
        padding: 12px 12px;
        border-radius: 14px;
        border: 1px solid #e5e7eb;
        outline: none;
        background:#fff;
        font-size: 14px;
        transition: border-color .15s ease, box-shadow .15s ease, background .15s ease;
    }
    .input:focus{
        border-color:#111827;
        box-shadow: 0 0 0 4px rgba(17,24,39,.10);
    }
    .row{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap: 10px;
        margin-top: 10px;
    }
    .mini{
        font-size: 12px;
        color:#64748b;
        line-height: 1.4;
    }

    .btn{
        width:100%;
        padding: 12px 14px;
        border-radius: 14px;
        border: 0;
        cursor:pointer;
        font-weight: 950;
        font-size: 14px;
        background:#111827;
        color:#fff;
        box-shadow: 0 14px 20px rgba(17,24,39,.14);
        transition: transform .05s ease, filter .15s ease;
        margin-top: 14px;
    }
    .btn:hover{ filter: brightness(1.06); }
    .btn:active{ transform: translateY(1px); }

    .links{
        margin-top: 12px;
        display:flex;
        justify-content:space-between;
        gap: 10px;
        flex-wrap: wrap;
    }
    .link{
        font-size: 12px;
        font-weight: 900;
        color:#111827;
        text-decoration: underline;
        text-underline-offset: 3px;
    }

    .alert{
        margin: 12px 18px 0;
        border-radius: 14px;
        padding: 12px 14px;
        border: 1px solid transparent;
        font-size: 13px;
        line-height: 1.45;
    }
    .alert-error{ background:#fef2f2; border-color:#fecaca; color:#7f1d1d; }
</style>

<div class="auth-wrap">
    <div class="auth-shell">

        
        <section class="card hero">
            <div class="hero-inner">
                <div class="brand">
                    <span class="brand-dot"></span>
                    Merchant Portal
                </div>

                <h1>Sign in to manage your eCheck payments</h1>
                <p>
                    View customer payments, track pending vs cleared eChecks, and manage your bank connection — all in one place.
                </p>

                <div class="hero-bullets">
                    <div class="bullet">
                        <div class="ic">✓</div>
                        <div class="txt"><strong style="color:#fff;">Dashboard</strong> with quick status filters (Pending / Cleared / Rejected).</div>
                    </div>
                    <div class="bullet">
                        <div class="ic">⛁</div>
                        <div class="txt"><strong style="color:#fff;">Payment link</strong> you can share with customers instantly.</div>
                    </div>
                    <div class="bullet">
                        <div class="ic">⚡</div>
                        <div class="txt"><strong style="color:#fff;">Fast setup</strong> — manual bank connect while Plaid is disabled.</div>
                    </div>
                </div>
            </div>
        </section>

        
        <section class="card">
            <div class="form-head">
                <h2 class="form-title">Merchant Login</h2>
                <p class="form-sub">Enter your email and password to continue.</p>
            </div>

            <?php if(session('error')): ?>
                <div class="alert alert-error">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-error">
                    <ul style="margin:0; padding-left: 18px;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($e); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form">
                <form method="POST" action="<?php echo e(route('merchant.login.store')); ?>" autocomplete="on">
                    <?php echo csrf_field(); ?>

                    <div class="field">
                        <label class="label" for="email">Email</label>
                        <input
                            id="email"
                            type="email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            class="input"
                            placeholder="you@business.com"
                            required
                            autofocus
                        />
                    </div>

                    <div class="field">
                        <div class="row" style="margin-bottom:6px;">
                            <label class="label" for="password" style="margin:0;">Password</label>
                            
                            
                        </div>

                        <input
                            id="password"
                            type="password"
                            name="password"
                            class="input"
                            placeholder="••••••••"
                            required
                        />
                        <div class="mini" style="margin-top:8px;">
                            Keep your password private. If you’re on a shared computer, log out after use.
                        </div>
                    </div>

                    <button class="btn" type="submit">Login</button>

                    <div class="links">
                        <span class="mini">New merchant?</span>
                        <a class="link" href="<?php echo e(route('merchant.signup')); ?>">Create an account</a>
                    </div>
                </form>
            </div>
        </section>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/paycron-echeck/paycron-echeck/resources/views/merchant/login.blade.php ENDPATH**/ ?>