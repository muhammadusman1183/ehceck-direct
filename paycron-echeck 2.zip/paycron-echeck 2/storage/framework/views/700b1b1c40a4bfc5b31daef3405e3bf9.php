<style>
    .dash-wrap{
        max-width: 1200px;
        margin: 28px auto;
        padding: 0 14px;
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji","Segoe UI Emoji";
        color: #0f172a;
    }

    .shell{
        display:grid;
        grid-template-columns: 260px 1fr;
        gap: 16px;
        align-items:start;
    }
    @media (max-width: 980px){
        .shell{ grid-template-columns: 1fr; }
    }

    .card{
        background:#fff;
        border:1px solid #e5e7eb;
        border-radius: 18px;
        box-shadow: 0 12px 26px rgba(15,23,42,.06);
        overflow:hidden;
    }

    /* Sidebar */
    .sidebar{
        position: sticky;
        top: 14px;
    }
    @media (max-width: 980px){
        .sidebar{ position: static; }
    }

    .side-head{
        padding: 18px 18px 14px;
        border-bottom:1px solid #e5e7eb;
        background: linear-gradient(180deg,#f8fafc 0%, #ffffff 100%);
    }
    .brand{
        font-weight: 900;
        letter-spacing: -.02em;
        font-size: 16px;
        display:flex;
        align-items:center;
        gap:10px;
    }
    .brand-dot{
        width: 10px; height: 10px; border-radius:999px;
        background:#111827;
        box-shadow: 0 0 0 4px rgba(17,24,39,.10);
    }
    .merchant-mini{
        margin-top: 10px;
        font-size: 13px;
        color:#64748b;
        line-height:1.35;
    }
    .pill{
        display:inline-flex;
        align-items:center;
        gap:8px;
        padding: 6px 10px;
        border-radius:999px;
        border:1px solid #e5e7eb;
        background:#fff;
        font-size:12px;
        font-weight:800;
        color:#0f172a;
        margin-top: 10px;
    }
    .pill-dot{
        width:8px;height:8px;border-radius:999px;background:#94a3b8;
    }
    .pill-dot.approved{ background:#22c55e; box-shadow:0 0 0 4px rgba(34,197,94,.12); }
    .pill-dot.pending{ background:#f59e0b; box-shadow:0 0 0 4px rgba(245,158,11,.12); }
    .pill-dot.rejected{ background:#ef4444; box-shadow:0 0 0 4px rgba(239,68,68,.12); }

    .side-body{ padding: 12px; }
    .nav{
        display:flex;
        flex-direction:column;
        gap: 8px;
    }
    .nav a{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding: 10px 12px;
        border-radius: 12px;
        text-decoration:none;
        color:#0f172a;
        border: 1px solid transparent;
        background:#fff;
        transition: background .15s ease, border-color .15s ease, transform .05s ease;
        font-weight: 800;
        font-size: 13px;
    }
    .nav a:hover{
        background:#f8fafc;
        border-color:#e5e7eb;
    }
    .nav a.active{
        background:#111827;
        color:#fff;
        border-color:#111827;
        box-shadow: 0 12px 18px rgba(17,24,39,.12);
    }
    .count{
        display:inline-flex;
        min-width: 28px;
        height: 22px;
        align-items:center;
        justify-content:center;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 900;
        background:#f1f5f9;
        color:#0f172a;
        padding: 0 8px;
    }
    .nav a.active .count{
        background: rgba(255,255,255,.18);
        color:#fff;
    }

    .side-foot{
        padding: 12px 16px 16px;
        border-top: 1px solid #e5e7eb;
        display:flex;
        gap:10px;
        align-items:center;
        justify-content:space-between;
    }
    .btn{
        border: 0;
        border-radius: 12px;
        padding: 10px 12px;
        font-weight: 900;
        font-size: 13px;
        cursor:pointer;
        text-decoration:none;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap: 10px;
        transition: transform .05s ease, filter .15s ease;
        white-space:nowrap;
    }
    .btn:active{ transform: translateY(1px); }
    .btn-ghost{
        background:transparent;
        border:1px solid #e5e7eb;
        color:#0f172a;
    }
    .btn-ghost:hover{ background:#fff; }
    .btn-dark{
        background:#111827;
        color:#fff;
        box-shadow: 0 12px 18px rgba(17,24,39,.12);
    }
    .btn-dark:hover{ filter: brightness(1.05); }

    /* Main header */
    .main-head{
        padding: 18px 18px 14px;
        border-bottom:1px solid #e5e7eb;
        background: linear-gradient(180deg,#ffffff 0%, #f8fafc 140%);
    }
    .hrow{
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap: 14px;
        flex-wrap: wrap;
    }
    .title{
        margin:0;
        font-size: 18px;
        font-weight: 950;
        letter-spacing: -.02em;
    }
    .subtitle{
        margin: 6px 0 0;
        color:#64748b;
        font-size: 13px;
        line-height:1.35;
    }
    .right-actions{
        display:flex;
        gap:10px;
        align-items:center;
        flex-wrap:wrap;
    }

    /* Alerts + tiles */
    .alert{
        margin: 14px 18px 0;
        border-radius: 14px;
        padding: 12px 14px;
        border: 1px solid transparent;
        font-size: 13px;
        line-height: 1.45;
    }
    .alert-warn{ background:#fffbeb; border-color:#fde68a; color:#92400e; }

    .main-body{ padding: 16px 18px 18px; }

    .tiles{
        display:grid;
        grid-template-columns: repeat(12, 1fr);
        gap: 12px;
        margin-bottom: 14px;
    }
    @media (max-width: 980px){
        .tiles{ grid-template-columns: 1fr; }
    }
    .tile{
        grid-column: span 4;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        background:#fff;
        padding: 14px 14px 12px;
    }
    @media (max-width: 980px){
        .tile{ grid-column: span 12; }
    }
    .tile .k{ font-size:12px; color:#64748b; font-weight:800; }
    .tile .v{ margin-top:6px; font-size:18px; font-weight:950; }
    .tile .s{ margin-top:6px; font-size:12px; color:#64748b; line-height:1.35; }

    .mono{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }

    /* Table */
    .table-wrap{
        border:1px solid #e5e7eb;
        border-radius: 16px;
        overflow:hidden;
        background:#fff;
    }
    table{ width:100%; border-collapse: collapse; font-size: 13px; }
    thead{ background:#f8fafc; }
    th, td{ text-align:left; padding: 11px 12px; }
    tbody tr{ border-top:1px solid #eef2f7; }
    tbody tr:hover{ background:#fafafa; }

    .status{
        display:inline-flex;
        align-items:center;
        gap:8px;
        padding: 6px 10px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 900;
        border: 1px solid #e5e7eb;
        background:#fff;
        color:#0f172a;
    }
    .dot{ width:8px; height:8px; border-radius:999px; background:#94a3b8; }
    .dot.pending{ background:#f59e0b; box-shadow:0 0 0 4px rgba(245,158,11,.12); }
    .dot.cleared{ background:#22c55e; box-shadow:0 0 0 4px rgba(34,197,94,.12); }
    .dot.rejected{ background:#ef4444; box-shadow:0 0 0 4px rgba(239,68,68,.12); }

    .copybox{
        display:flex;
        gap:10px;
        align-items:center;
        justify-content:space-between;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        background:#f8fafc;
        padding: 10px 12px;
        overflow:auto;
    }
    .copybox .text{
        font-size: 12px;
        color:#0f172a;
        white-space: nowrap;
    }

    .mini{
        font-size: 12px;
        color:#64748b;
        line-height:1.35;
    }
</style>


<?php
    // coming from controller
    $active = $active ?? request('status', 'all');
    $statusCounts = $statusCounts ?? ['all'=>0,'pending'=>0,'cleared'=>0,'rejected'=>0];

    // Total amount for CURRENT PAGE (10 rows)
    $totalAmount = $pagination->getCollection()->sum('amount');

    // highlight sidebar item for dashboard + status filter
    $sidebarActive = in_array($active, ['pending','cleared','rejected'], true) ? $active : 'dashboard';
?>

<?php
    $isApproved = $isApproved ?? (strtolower((string) ($merchant->status ?? 'pending')) === 'approved');
?>

<?php $__env->startSection('merchant_main'); ?>
    <div class="main-head">
        <div class="hrow">
            <div>
                <h1 class="title">Merchant Dashboard</h1>
                <p class="subtitle">Overview of your customer eCheck payments and latest activity.</p>
            </div>

            <div class="right-actions">
                <?php if($bank): ?>
                    <a class="btn btn-ghost" href="<?php echo e(route('merchant.bank.connect')); ?>">
                        Connected: <?php echo e($bank->name ?? 'Bank'); ?> • ****<?php echo e($bank->mask ?? ''); ?>

                    </a>
                <?php else: ?>
                    <a class="btn btn-ghost" href="<?php echo e(route('merchant.bank.connect')); ?>">
                        Connect Bank
                    </a>
                <?php endif; ?>

                <?php if($isApproved && Route::has('merchant.echeck.create')): ?>
                    <a class="btn btn-dark" href="<?php echo e(route('merchant.echeck.create')); ?>">+ Create eCheck</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($merchant->status !== 'approved'): ?>
        <div class="alert alert-warn">
            Your account is not approved yet. Please
            <a style="text-decoration:underline;color:inherit;font-weight:800;" href="<?php echo e(route('merchant.bank.connect')); ?>">connect your bank</a>.
            Your eChecks may remain <strong>Pending</strong> until verification is enabled.
        </div>
    <?php else: ?>
        <div class="alert alert-ok">
            Your account is <strong>Approved</strong>. You can accept customer eChecks.
        </div>
    <?php endif; ?>

    <div class="main-body">
        <div class="tiles" style="display:grid;grid-template-columns:repeat(12,1fr);gap:12px;margin-bottom:14px;">
            <div class="tile" style="grid-column:span 4;">
                <div class="k">Showing</div>
                <div class="v"><?php echo e($active === 'all' ? 'All eChecks' : ucfirst($active).' eChecks'); ?></div>
                <div class="s">Use the sidebar to filter by status.</div>
            </div>

            <div class="tile" style="grid-column:span 4;">
                <div class="k">Count</div>
                <div class="v"><?php echo e($pagination->total()); ?></div>
                <div class="s">Echecks in the current view.</div>
            </div>

            <div class="tile" style="grid-column:span 4;">
                <div class="k">Total Amount</div>
                <div class="v">$<?php echo e(number_format((float)$totalAmount, 2)); ?></div>
                <div class="s">Sum of amounts in the current view.</div>
            </div>
        </div>

        <?php if(!$isApproved): ?>
            <div class="alert alert-warn">
                Your account is <strong><?php echo e(ucfirst($merchant->status ?? 'pending')); ?></strong>.
                eCheck features are hidden until your merchant profile is approved.
                Please <a style="text-decoration:underline;color:inherit;font-weight:800;" href="<?php echo e(route('merchant.bank.connect')); ?>">connect your bank</a>.
            </div>
        <?php else: ?>
        <div class="table-wrap">
            <form method="POST" action="<?php echo e(route('merchant.echeck.bulk.pdf')); ?>">
            <?php echo csrf_field(); ?>
            <div style="margin-top:16px; display:flex; gap:12px;margin-right: 50px;justify-content: flex-end;">
                    <button class="btn btn-dark" type="submit" style="font-size: 12px;margin-bottom: 20px;">
                        Print Selected eChecks (PDF)
                    </button>
                </div>
                <table>
                    <thead>
                    <tr>
                        <th>
                            <input type="checkbox" id="selectAll">
                        </th>
                        <th>Customer Name</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>View PDF</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $st = strtolower($tx->status ?? 'pending');
                            $dot = in_array($st, ['pending','cleared','rejected'], true) ? $st : 'pending';
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox"
                                    name="echecks[]"
                                    value="<?php echo e($tx->id); ?>"
                                    class="row-check">
                            </td>
                            <td class="mono"><?php echo e($tx->customer_name); ?></td>
                            <td>$<?php echo e(number_format((float)$tx->amount, 2)); ?></td>
                            <td>
                                <span class="status">
                                    <span class="dot <?php echo e($dot); ?>"></span>
                                    <?php echo e(ucfirst($st)); ?>

                                </span>
                            </td>
                            <td><?php echo e(optional($tx->created_at)->diffForHumans()); ?></td>
                            <td>
                                
                                <?php if(!empty($tx->pdf_path)): ?>
                                    <a class="btn btn-ghost"
                                    style="padding:8px 10px;border-radius:10px;font-size:12px;"
                                    target="_blank"
                                    href="<?php echo e(route('merchant.echeck.pdf', $tx)); ?>">
                                        View PDF
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" style="padding:18px;color:#64748b;">
                                No eCheck payments found for this filter.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>
        
        <?php if($pagination->hasPages()): ?>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:14px;gap:10px;flex-wrap:wrap;">
                <div class="mini">
                    Page <?php echo e($pagination->currentPage()); ?> of <?php echo e($pagination->lastPage()); ?>

                </div>

                <div style="display:flex;gap:10px;align-items:center;">
                    <?php if($pagination->onFirstPage()): ?>
                        <span class="btn btn-ghost" style="opacity:.45;cursor:not-allowed;">← Prev</span>
                    <?php else: ?>
                        <a class="btn btn-ghost" href="<?php echo e($pagination->previousPageUrl()); ?>">← Prev</a>
                    <?php endif; ?>

                    <?php if($pagination->hasMorePages()): ?>
                        <a class="btn btn-dark" href="<?php echo e($pagination->nextPageUrl()); ?>">Next →</a>
                    <?php else: ?>
                        <span class="btn btn-dark" style="opacity:.45;cursor:not-allowed;">Next →</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <div style="margin-top:12px;" class="mini">
            Tip: When Plaid is enabled, you can automatically verify bank accounts and move merchants to Approved faster.
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php
    // pass values to shell/sidebar
    $active = $sidebarActive;
?>

<script>
document.getElementById('selectAll')?.addEventListener('change', function () {
    document.querySelectorAll('.row-check').forEach(cb => {
        cb.checked = this.checked;
    });
});
</script>

<?php echo $__env->make('merchant.layouts.shell', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/paycron-echeck/paycron-echeck/resources/views/merchant/dashboard.blade.php ENDPATH**/ ?>