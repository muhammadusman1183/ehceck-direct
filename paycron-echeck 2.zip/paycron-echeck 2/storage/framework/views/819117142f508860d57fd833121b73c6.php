<?php
    // Required
    // $merchant

    // Optional
    // $bank
    // $active (string) e.g. 'dashboard'|'invoices'|'verify'|'pending'|'cleared'|'rejected'
    // $statusCounts (array) ['all'=>..,'pending'=>..,'cleared'=>..,'rejected'=>..]
    // $invoiceCounts (array) optional ['all'=>..,'draft'=>..,'sent'=>..,'paid'=>..,'void'=>..]
    // $paymentLink (string) optional

    $active = $active ?? 'dashboard';
    $statusCounts = $statusCounts ?? ['all'=>0,'pending'=>0,'cleared'=>0,'rejected'=>0];
    $invoiceCounts = $invoiceCounts ?? ['all'=>0,'draft'=>0,'sent'=>0,'paid'=>0,'void'=>0];
    $paymentLink = $paymentLink ?? (isset($merchant) ? route('customer.payment', $merchant) : '#');

    $pillStatus = strtolower($merchant->status ?? 'pending');
    $pillDot = in_array($pillStatus, ['approved','pending','rejected'], true) ? $pillStatus : 'pending';

    // Auto-detect echeck context as fallback even if $active isn't passed correctly
    $isEcheckActive = in_array($active, ['verify','pending','cleared','rejected'], true)
        || request()->query('status') !== null;

    // Total count for dropdown badge
    $echeckTotal = (int)($statusCounts['pending'] ?? 0)
        + (int)($statusCounts['cleared'] ?? 0)
        + (int)($statusCounts['rejected'] ?? 0);
?>

<style>
    /* dropdown styling - matches your nav */
    .nav details{ border-radius: 12px; }

    .nav summary{
        list-style:none;
        cursor:pointer;
        user-select:none;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding: 10px 12px;
        border-radius: 12px;
        color:#0f172a;
        border: 1px solid transparent;
        background:#fff;
        transition: background .15s ease, border-color .15s ease, transform .05s ease;
        font-weight: 800;
        font-size: 13px;
    }
    .nav summary:hover{
        background:#f8fafc;
        border-color:#e5e7eb;
    }
    .nav summary::-webkit-details-marker{ display:none; }

    /* chevron bubble */
    .chev{
        width: 18px; height: 18px;
        display:inline-flex; align-items:center; justify-content:center;
        border-radius: 999px;
        background:#f1f5f9;
        color:#0f172a;
        font-weight: 900;
        transform: rotate(0deg);
        transition: transform .15s ease;
        flex: 0 0 auto;
    }
    details[open] .chev{ transform: rotate(180deg); }

    /* parent active style */
    .nav details.echeck-active summary{
        background:#111827;
        color:#fff;
        border-color:#111827;
        box-shadow: 0 12px 18px rgba(17,24,39,.12);
    }
    .nav details.echeck-active summary .count{
        background: rgba(255,255,255,.18);
        color:#fff;
    }
    .nav details.echeck-active summary .chev{
        background: rgba(255,255,255,.18);
        color:#fff;
    }

    /* sub-links container */
    .echeck-sub{
        margin-top:8px;
        margin-left:10px;
        padding-left:14px;
        border-left:2px solid #e5e7eb;
        display:flex;
        flex-direction:column;
        gap:8px;
    }

    /* sub-links should still look like nav links */
    .nav .sub-link{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding: 10px 12px;
        border-radius: 12px;
        text-decoration:none;
        color:#0f172a;
        border: 1px solid transparent;
        background:#fff;
        transition: background .15s ease, border-color .15s ease;
        font-weight: 800;
        font-size: 13px;
    }
    .nav .sub-link:hover{
        background:#f8fafc;
        border-color:#e5e7eb;
    }
    .nav .sub-link.active{
        background:#111827;
        color:#fff;
        border-color:#111827;
        box-shadow: 0 12px 18px rgba(17,24,39,.12);
    }
    .nav .sub-link.active .count{
        background: rgba(255,255,255,.18);
        color:#fff;
    }
</style>

<aside class="card sidebar">
    <div class="side-head">
        <div class="brand">
            <span class="brand-dot"></span>
            Merchant Portal
        </div>

        <div class="merchant-mini">
            Signed in as <strong><?php echo e($merchant->name); ?></strong><br>
            <span class="mono"><?php echo e($merchant->email ?? ''); ?></span>
        </div>

        <div class="pill">
            <span class="pill-dot <?php echo e($pillDot); ?>"></span>
            Status: <?php echo e(ucfirst($merchant->status)); ?>

            <?php if($merchant->verified_at): ?>
                <span style="font-weight:700;color:#64748b;">Verified</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="side-body">
        <div class="nav">

            
            <a href="<?php echo e(route('merchant.dashboard')); ?>" class="<?php echo e($active==='dashboard' ? 'active' : ''); ?>">
                Dashboard
            </a>

            
            <!-- <?php if(Route::has('merchant.invoices.index')): ?>
                <a href="<?php echo e(route('merchant.invoices.index')); ?>" class="<?php echo e($active==='invoices' ? 'active' : ''); ?>">
                    Invoices
                    <span class="count"><?php echo e((int)($invoiceCounts['all'] ?? 0)); ?></span>
                </a>
            <?php endif; ?> -->

            
            <?php if($isApproved): ?>
            <details class="<?php echo e($isEcheckActive ? 'echeck-active' : ''); ?>" <?php echo e($isEcheckActive ? 'open' : ''); ?>>
                <summary>
                    <span>eChecks</span>
                    <span style="display:flex;align-items:center;gap:8px;">
                        <span class="chev">⌄</span>
                    </span>
                </summary>

                <div class="echeck-sub">
                    
                    <?php if(Route::has('merchant.echeck.verify.index')): ?>
                        <a href="<?php echo e(route('merchant.echeck.verify.index')); ?>"
                           class="sub-link <?php echo e($active==='verify' ? 'active' : ''); ?>">
                            Verification
                            <span class="count"><?php echo e((int)($statusCounts['pending'] ?? 0)); ?></span>
                        </a>
                    <?php endif; ?>

                    
                    <a href="<?php echo e(route('merchant.dashboard', ['status' => 'pending'])); ?>"
                       class="sub-link <?php echo e($active==='pending' ? 'active' : ''); ?>">
                        Pending eChecks
                        <span class="count"><?php echo e((int)($statusCounts['pending'] ?? 0)); ?></span>
                    </a>

                    
                    <a href="<?php echo e(route('merchant.dashboard', ['status' => 'cleared'])); ?>"
                       class="sub-link <?php echo e($active==='cleared' ? 'active' : ''); ?>">
                        Cleared eChecks
                        <span class="count"><?php echo e((int)($statusCounts['cleared'] ?? 0)); ?></span>
                    </a>

                    
                    <a href="<?php echo e(route('merchant.dashboard', ['status' => 'rejected'])); ?>"
                       class="sub-link <?php echo e($active==='rejected' ? 'active' : ''); ?>">
                        Rejected eChecks
                        <span class="count"><?php echo e((int)($statusCounts['rejected'] ?? 0)); ?></span>
                    </a>
                </div>
            </details>
            <?php endif; ?>
        </div>

        <div style="margin-top:12px;">
            <div class="mini"><strong>Payment Link</strong></div>
            <div class="mini" style="margin-top:6px;">
                Share this link with customers to pay you by eCheck.
            </div>

            <div class="copybox" style="margin-top:10px;">
                <div class="text mono"><?php echo e($paymentLink); ?></div>
                <button type="button" class="btn btn-ghost"
                        onclick="navigator.clipboard.writeText('<?php echo e($paymentLink); ?>')">
                    Copy
                </button>
            </div>
        </div>
    </div>

    <div class="side-foot">
        <a class="btn btn-ghost" href="<?php echo e(route('merchant.bank.connect')); ?>">
            Bank
        </a>

        <form method="POST" action="<?php echo e(route('merchant.logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-dark" type="submit">Logout</button>
        </form>
    </div>
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/paycron-echeck/paycron-echeck/resources/views/merchant/partials/sidebar.blade.php ENDPATH**/ ?>