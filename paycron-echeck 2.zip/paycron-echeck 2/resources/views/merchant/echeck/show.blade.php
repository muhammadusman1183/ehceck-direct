<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>eCheck #{{ $echeck->id }}</title>
    <style>
        @font-face {
            font-family: 'MICR';
            src: url("{{ public_path('fonts/MICR_E13B.ttf') }}") format('truetype');
            font-weight: normal;
            font-style: normal;
        }

        /* DomPDF-safe page */
        @page {
            margin: 18px;
        }

        body {
            font-family: DejaVu Sans, Arial, Helvetica, sans-serif;
            color: #000;
            font-size: 15px;
        }

        /* CHECK CONTAINER */
        .check {
            width: 100%;
            height: 300px;
            padding: 25px 45px;
            box-sizing: border-box;
        }

        .row {
            width: 100%;
        }

        /* TOP SECTION */
        .top {
            display: table;
            width: 100%;
            margin-bottom: 6px;
        }

        .top .left,
        .top .right {
            display: table-cell;
            vertical-align: top;
        }

        .top .left {
            width: 65%;
        }

        .top .right {
            width: 35%;
            text-align: right;
        }

        .name {
            font-size: 17px;
            font-weight: 700;
            margin-bottom: 2px;
        }

        .addr {
            font-size: 15px;
            line-height: 1.2;
        }

        .checkno {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .bankline {
            font-size: 15px;
            margin-bottom: 4px;
            text-align: left;
        }

        .datebox {
            display: inline-block;
            width: 110px;
            border-bottom: 1px solid #000;
            padding-bottom: 2px;
            text-align: right;
            font-size: 15px;
        }

        /* PAYEE + AMOUNT */
        .payrow {
            display: table;
            width: 100%;
            margin-top: 6px;
        }

        .payrow .label {
            display: table-cell;
            width: 88px;
            font-size: 15px;
            vertical-align: middle;
        }

        .payrow .payee {
            display: table-cell;
            border: 1px 0px 0px 0px solid #000;
            padding: 6px 10px;
            height: 24px;
            font-size: 20px;
            text-transform: uppercase;
            border-top: 0;
            border-right: 0;
            border-bottom: 2px solid #000;
            border-left: 2px solid #000;
        }

        .payrow .amountcell {
            display: table-cell;
            width: 150px;
            padding-left: 10px;
            vertical-align: middle;
        }

        .amountbox {
            border: 1px solid #000;
            height: 26px;
            padding: 4px 8px;
            display: table;
            width: 100%;
        }

        .amountbox .dollar {
            display: table-cell;
            width: 16px;
            font-weight: 700;
            vertical-align: middle;
        }

        .amountbox .amt {
            display: table-cell;
            text-align: left;
            font-weight: 700;
            font-size: 15px;
            vertical-align: middle;
        }

        /* AMOUNT IN WORDS */
        .words {
            display: table;
            width: 100%;
            margin-top: 10px;
        }

        .words .line {
            display: table-cell;
            padding: 6px 10px;
            height: 24px;
            font-size: 20px;
            border-top: 0;
            border-right: 0;
            border-bottom: 2px solid #000;
            border-left: 2px solid #000;
        }

        .words .dollars {
            display: table-cell;
            width: 62px;
            padding-left: 6px;
            font-weight: 700;
            font-size: 15px;
        }

        /* MIDDLE SECTION */
        .mid {
            display: table;
            width: 100%;
            margin-top: 10px;
        }

        .mid .left,
        .mid .right {
            display: table-cell;
            vertical-align: top;
        }

        .mid .left {
            width: 55%;
        }

        .mid .right {
            width: 45%;
            padding-left: 14px;
        }

        .sig {
            text-align: center;
            font-weight: 800;
            font-size: 14px;
            margin-bottom: 4px;
        }

        .small {
            font-size: 10px;
            line-height: 1.25;
        }

        .memo {
            margin-top: 10px;
            display: table;
            width: 100%;
        }

        .memo .label {
            display: table-cell;
            width: 50px;
            font-size: 15px;
            vertical-align: bottom;
        }

        .memo .line {
            display: table-cell;
            border-bottom: 2px solid #000;
            height: 14px;
        }

        /* MICR */
        .micr {
            margin-top: 25px;
            text-align: center;
            font-family: 'MICR';
            font-size: 24px;
            letter-spacing: 1px;
            line-height: 1;
        }

        .micr span {
            display: inline-block;
            margin: 0 15px;
        }
        /* Action buttons container */
.actions {
    display: flex;
    justify-content: center;
    gap: 14px;
    margin-top: 28px;
    padding-top: 18px;
    border-top: 1px solid #e5e7eb;
}

/* Base button */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 12px 18px;
    border-radius: 14px;
    font-size: 14px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
    white-space: nowrap;
    transition: transform .05s ease, box-shadow .15s ease, background .15s ease;
}

/* Back to dashboard */
.btn-ghost {
    background: #ffffff;
    color: #0f172a;
    border: 1px solid #e5e7eb;
}

.btn-ghost:hover {
    background: #f8fafc;
    box-shadow: 0 6px 12px rgba(15, 23, 42, 0.08);
}

/* Download PDF */
.btn-dark {
    background: #111827;
    color: #ffffff;
    border: 1px solid #111827;
    box-shadow: 0 10px 18px rgba(17, 24, 39, 0.18);
}

.btn-dark:hover {
    background: #020617;
    box-shadow: 0 14px 22px rgba(17, 24, 39, 0.25);
}

/* Click feedback */
.btn:active {
    transform: translateY(1px);
}

    </style>

</head>

<body>

    @php
    // These should come from your DB/eCheck + merchant profile fields:
    $payerName = merchant_name_by_id($echeck->merchant_id);


    $bankLabel = $echeck->bank_name ?? 'Bank';
    $checkNo = $echeck->id; // or your own check_number column
    $date = optional($echeck->created_at)->format('m/d/Y') ?? date('m/d/Y');

    $payee = $merchant->payee_name ?? ($merchant->name ?? 'PAYEE'); // or invoice payee
    $amount = number_format((float)$echeck->amount, 2);

    // Amount words — use your helper (fallback if intl not installed)
    $amountWords = function_exists('amount_to_words')
    ? amount_to_words((float)$echeck->amount)
    : $amount.' dollars';

    // Routing/account (masked)
    $rt = $echeck->routing_number ?? '000000000';
    $acctLast4 = $echeck->account_last4 ?? '0000';

    // Fake MICR layout (visual only)
    // You can store real micr values (routing + account + check no) if you want.
    $micrRouting = $rt;
    $micrAccount = $echeck->account_number; // just a visual placeholder
    $micrCheck = str_pad((string)$checkNo, 4, '0', STR_PAD_LEFT);

    $bankHolderName = $echeck->account_holder_name ?? '';
    $payerAddr1 = $echeck->account_holder_address1 ?? '';
    $payerAddr2 = $echeck->account_holder_address2 ?? '';

    $transit = "⑆"; // routing
    $onus = "⑈"; // account / check
    @endphp

    <div class="section" style="padding: 100px;">
        <div class="check">

            <div class="top">
                <div class="left">
                    <div class="name">{{ $bankHolderName }}</div>
                    <div class="addr">{{ $payerAddr1 }}</div>
                    <div class="addr">{{ $payerAddr2 }}</div>
                </div>
                <div class="right">
                    <div class="checkno">{{ $micrCheck }}</div>
                    <div class="bankline">{{ $bankLabel }}</div>
                    <div class="datebox">{{ $date }}</div>
                </div>
            </div>

            <div class="payrow">
                <div class="label">Pay To The<br>Order Of</div>

                <div class="payee">{{ strtoupper($payerName) }}</div>

                <div class="amountcell">
                    <div class="amountbox">
                        <div class="dollar">$</div>
                        <div class="amt">{{ $amount }}</div>
                    </div>
                </div>
            </div>

            <div class="words">
                <div class="line">{{ $amountWords }}</div>
                <div class="dollars">Dollars</div>
            </div>

            <div class="mid" style="margin-top: 30px;">
                <div class="left">
                    <div class="small" style="margin-top:18px;font-size: 15px;">
                        Customer Authorization Obtained:&nbsp;&nbsp;&nbsp;&nbsp;{{ $date }}
                    </div>

                    <div class="memo">
                        <div class="label">Memo</div>
                        <div class="line"></div>
                    </div>
                </div>

                <div class="right">
                    <div class="sig">SIGNATURE NOT REQUIRED</div>
                    <div class="small" style="margin-left: 100px;">
                        Payment has been authorized by the depositor.<br>
                        Payee to hold you harmless for payment of this document.<br>
                        This document shall be deposited only to credit of payee.<br>
                        Absence of endorsement is guaranteed by payee's bank.
                    </div>
                </div>
            </div>

            <div class="micr">
                <span>{{ $onus }}{{ $micrCheck }}{{ $onus }}</span>
                <span>{{ $transit }}{{ $micrRouting }}{{ $transit }}</span>
                <span>{{ $micrAccount }}{{ $onus }}</span>
            </div>

            {{-- ✅ BUTTONS BELOW CHECK --}}
            <div class="actions">
    <a href="{{ route('merchant.dashboard') }}" class="btn btn-ghost">
        ← Back to Dashboard
    </a>

    <a href="{{ route('merchant.echeck.pdf', $echeck) }}"
       class="btn btn-dark"
       target="_blank">
        Download PDF
    </a>
</div>


        </div>
    </div>
</body>

</html>