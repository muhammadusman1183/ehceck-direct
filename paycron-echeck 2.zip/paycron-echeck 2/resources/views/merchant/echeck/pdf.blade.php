<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>eCheck #{{ $echeck->id }}</title>

    <style>
        @font-face {
            font-family: 'MICR';
            src: url("{{ public_path('fonts/MICR_E13B.ttf') }}") format('truetype');
            font-weight: normal;
            font-style: normal;
        }

        @page { margin: 18px; }

        body{
            font-family: DejaVu Sans, Arial, Helvetica, sans-serif;
            color:#000;
            font-size: 15px;
        }

        .check{
            width: 95%;
            height: 300px;
            padding: 25px 28px;
            box-sizing: border-box;
        }

        /* top info */
        .name{ font-size: 17px; font-weight: 700; margin-bottom: 2px; }
        .addr{ font-size: 15px; line-height: 1.2; }
        .checkno{ font-size: 16px; font-weight: 700; margin-bottom: 8px; }
        .bankline{ font-size: 15px; margin-bottom: 4px; text-align: left; }
        .datebox{
            display:inline-block;
            width:95px;
            border-bottom:1px solid #000;
            padding-bottom:2px;
            text-align:right;
            font-size:15px;
        }

        /* pay row */
        .label{ width: 88px; font-size: 15px; vertical-align: middle; }
        .payee{
            padding: 6px 10px;
            height: 20px;
            font-size: 20px;
            text-transform: uppercase;
            border-bottom: 2px solid #000;
            border-left: 2px solid #000;
        }

        .amountcell{ width:150px; padding-left:10px; vertical-align: middle; }
        .amountbox{
            border: 1px solid #000;
            height: 30px;
            padding: 4px 8px;
            width: 100%;
        }
        .amountbox td{ vertical-align: middle; }
        .dollar{ width:16px; font-weight:700; }
        .amt{ text-align:left; font-weight:700; font-size:15px; }

        /* words line */
        .wordsline{
            padding: 6px 10px;
            height: 24px;
            font-size: 20px;
            border-bottom: 2px solid #000;
            border-left: 2px solid #000;
        }
        .dollars{ width: 62px; padding-left: 6px; font-weight: 700; font-size: 15px; }

        /* memo */
        .small{ font-size: 10px; line-height: 1.25; }
        .memoLabel{ width: 50px; font-size: 15px; vertical-align: bottom; }
        .memoLine{ border-bottom: 2px solid #000; height: 14px; }

        /* micr */
        .micr{
            margin-top: 25px;
            text-align: center;
            font-family: 'MICR';
            font-size: 24px;
            letter-spacing: 1px;
            line-height: 1;
        }
        .micr span{ display:inline-block; margin: 0 15px; }
        .top .right{
            width: 35%;
            text-align: right;
        }
        .payrow .amountcell{
            width: 135px;      /* ✅ was 150px */
            padding-left: 10px;
            vertical-align: middle;
        }
    </style>
</head>

<body>
@php
    $payerName = merchant_name_by_id($echeck->merchant_id);

    $bankLabel = $echeck->bank_name ?? 'Bank';
    $checkNo = $echeck->id;
    $date = optional($echeck->created_at)->format('m/d/Y') ?? date('m/d/Y');

    $amount = number_format((float)$echeck->amount, 2);

    $amountWords = function_exists('amount_to_words')
        ? amount_to_words((float)$echeck->amount)
        : $amount.' dollars';

    $rt = $echeck->routing_number ?? '000000000';
    $micrAccount = $echeck->account_number ?? '000000000000';
    $micrCheck = str_pad((string)$checkNo, 4, '0', STR_PAD_LEFT);

    $bankHolderName = $echeck->account_holder_name ?? '';
    $payerAddr1 = $echeck->account_holder_address1 ?? '';
    $payerAddr2 = $echeck->account_holder_address2 ?? '';

    $transit = "⑆";
    $onus = "⑈";
@endphp

<div class="check">

    <!-- TOP -->
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:6px; table-layout:fixed;">
        <tr>
            <td width="65%" valign="top">
                <div class="name">{{ $bankHolderName }}</div>
                <div class="addr">{{ $payerAddr1 }}</div>
                <div class="addr">{{ $payerAddr2 }}</div>
            </td>
            <td width="35%" valign="top" align="right">
                <div class="checkno">{{ $micrCheck }}</div>
                <div class="bankline">{{ $bankLabel }}</div>
                <div class="datebox">{{ $date }}</div>
            </td>
        </tr>
    </table>

    <!-- PAYEE + AMOUNT -->
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:6px;">
        <tr>
            <td class="label">Pay To The<br>Order Of</td>
            <td class="payee">{{ strtoupper($payerName) }}</td>
            <td class="amountcell">
                <table class="amountbox" cellpadding="0" cellspacing="0">
                    <tr>
                        <td class="dollar">$</td>
                        <td class="amt">{{ $amount }}</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    <!-- WORDS -->
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:10px;">
        <tr>
            <td class="wordsline">{{ $amountWords }}</td>
            <td class="dollars">Dollars</td>
        </tr>
    </table>

    <!-- MID -->
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:30px;">
        <tr>
            <td width="55%" valign="top">
                <div style="margin-top:18px;font-size:15px;">
                    Customer Authorization Obtained:&nbsp;&nbsp;&nbsp;&nbsp;{{ $date }}
                </div>

                <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:10px;">
                    <tr>
                        <td class="memoLabel">Memo</td>
                        <td class="memoLine"></td>
                    </tr>
                </table>
            </td>
            <td width="45%" valign="top" style="padding-left:14px;">
                <div style="text-align:center;font-weight:800;font-size:14px;margin-bottom:4px;">SIGNATURE NOT REQUIRED</div>
                <div class="small" style="margin-left:100px;">
                    Payment has been authorized by the depositor.<br>
                    Payee to hold you harmless for payment of this document.<br>
                    This document shall be deposited only to credit of payee.<br>
                    Absence of endorsement is guaranteed by payee's bank.
                </div>
            </td>
        </tr>
    </table>

    <!-- MICR -->
    <div class="micr">
        <span>{{ $onus }}{{ $micrCheck }}{{ $onus }}</span>
        <span>{{ $transit }}{{ $rt }}{{ $transit }}</span>
        <span>{{ $micrAccount }}{{ $onus }}</span>
    </div>

</div>
</body>
</html>
