<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MerchantController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\CustomerPaymentController;
use App\Http\Controllers\MerchantInvoiceController;
use App\Http\Controllers\MerchantEcheckController;
use App\Http\Controllers\CustomerInvoicePaymentController;
use App\Http\Controllers\MerchantEcheckVerificationController;
use Barryvdh\DomPDF\Facade\Pdf;

Route::get('/', fn () => view('welcome'));

Route::get('/test-pdf', function () {
    return Pdf::loadHTML('<h1>PDF Works ✅</h1>')->stream('test.pdf');
});

// Merchant onboarding + dashboard
Route::get('/merchant/signup', [MerchantController::class, 'showSignup'])->name('merchant.signup');
Route::post('/merchant/signup', [MerchantController::class, 'storeSignup'])->name('merchant.signup.store');

Route::get('/merchant/login', [MerchantController::class, 'showLogin'])->name('merchant.login');
Route::post('/merchant/login', [MerchantController::class, 'login'])->name('merchant.login.store');
Route::post('/merchant/logout', [MerchantController::class, 'logout'])->name('merchant.logout');

Route::middleware('merchant.auth')->group(function () {
    Route::get('/merchant/dashboard', [MerchantController::class, 'dashboard'])->name('merchant.dashboard');
    Route::get('/merchant/bank/connect', [MerchantController::class, 'bankConnect'])->name('merchant.bank.connect');

    // Plaid merchant verification endpoints (web)
    Route::post('/merchant/plaid/link-token', [MerchantController::class, 'createLinkToken'])->name('merchant.plaid.link_token');
    Route::post('/merchant/plaid/exchange', [MerchantController::class, 'exchangePublicToken'])->name('merchant.plaid.exchange');
    

    // Route::get('/merchant/invoices',[InvoiceController::class,'index'])->name('merchant.invoices');
    // Route::get('/merchant/invoices/create',[InvoiceController::class,'create']);
    // Route::post('/merchant/invoices',[InvoiceController::class,'store']);

    Route::get('/merchant/invoices', [MerchantInvoiceController::class, 'index'])->name('merchant.invoices.index');
    Route::get('/merchant/invoices/create', [MerchantInvoiceController::class, 'create'])->name('merchant.invoices.create');
    Route::post('/merchant/invoices', [MerchantInvoiceController::class, 'store'])->name('merchant.invoices.store');
    Route::get('/merchant/invoices/{invoice}', [MerchantInvoiceController::class, 'show'])->name('merchant.invoices.show');

    Route::get('/merchant/echecks', [MerchantEcheckController::class, 'index'])->name('merchant.echecks.index');

    // Customer invoice pay page
    Route::get('/pay/{token}', [CustomerInvoicePaymentController::class, 'payPage'])->name('customer.invoice.pay');
    Route::post('/pay/{token}/link-token', [CustomerInvoicePaymentController::class, 'createLinkToken'])->name('customer.invoice.link_token');
    Route::post('/pay/{token}/submit', [CustomerInvoicePaymentController::class, 'submit'])->name('customer.invoice.submit');
    
    Route::get('/merchant/echeck/verify', [MerchantEcheckVerificationController::class, 'index'])
        ->name('merchant.echeck.verify.index');

    Route::post('/merchant/echeck/verify/link-token', [MerchantEcheckVerificationController::class, 'linkToken'])
        ->name('merchant.echeck.verify.link_token');

    Route::post('/merchant/echeck/verify/submit', [MerchantEcheckVerificationController::class, 'submit'])
        ->name('merchant.echeck.verify.submit');

    
    Route::get('/merchant/echeck/create', [MerchantEcheckController::class, 'create'])
        ->name('merchant.echeck.create');

    Route::post('/merchant/echeck/link-token', [MerchantEcheckController::class, 'linkToken'])
        ->name('merchant.echeck.link_token');

    Route::post('/merchant/echeck/store', [MerchantEcheckController::class, 'store'])
        ->name('merchant.echeck.store');

    Route::get('/merchant/echeck/{echeck}', [MerchantEcheckController::class, 'show'])
        ->name('merchant.echeck.show');

    Route::get('/merchant/echeck/{echeck}/pdf', [MerchantEcheckController::class, 'pdf'])
        ->name('merchant.echeck.pdf');

    Route::post('/merchant/echecks/bulk-pdf',[MerchantController::class, 'bulkPdf'])
        ->name('merchant.echeck.bulk.pdf');

});

Route::get('/merchant/bank/manual', [MerchantController::class, 'showManualBankForm'])
    ->name('merchant.bank.manual');

Route::post('/merchant/bank/manual', [MerchantController::class, 'storeManualBank'])
    ->name('merchant.bank.manual.store');
// Customer payment flow
Route::get('/pay/{merchant}', [PaymentController::class, 'showPayment'])->name('customer.payment');
Route::post('/pay/{merchant}/plaid/link-token', [PaymentController::class, 'createCustomerLinkToken'])->name('customer.plaid.link_token');
Route::post('/pay/{merchant}/plaid/exchange', [PaymentController::class, 'exchangeCustomerPublicToken'])->name('customer.plaid.exchange');
Route::post('/pay/{merchant}/submit', [PaymentController::class, 'submitPayment'])->name('customer.payment.submit');

Route::get('/pay/{uuid}',[CustomerPaymentController::class,'show']);
Route::post('/pay/{uuid}/bank',[CustomerPaymentController::class,'saveBank']);
Route::post('/pay/{uuid}/verify',[CustomerPaymentController::class,'verify']);
Route::post('/pay/{uuid}/submit',[CustomerPaymentController::class,'submit']);
